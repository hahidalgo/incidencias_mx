export enum ChannelEnum {
  Web = 'web',
  Mobile = 'web_mobile',
  App = 'app',
  DevDevice = 'dev_device',
}
