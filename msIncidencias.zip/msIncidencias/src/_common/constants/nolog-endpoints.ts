export const noLogEndpoints = [];
