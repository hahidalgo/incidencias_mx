export enum msArquetipoResponseCodes {
  TokenInvalido = 'MSARQ-01',
  CaptchaInvalido = 'MSARQ-02',
  Forbidden = 'MSARQ-03',
  Unhandled = 'MSARQ-04',
}
