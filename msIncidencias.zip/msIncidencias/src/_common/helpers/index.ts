export * from './detect-device.helper';
export * from './sanitize-id-card-component.helper';
